import { apiClient } from './client'
import type { BookRequest, BookResponse, BookSummary } from '@/types/book'

export const booksApi = {
  async generate(payload: BookRequest): Promise<BookResponse> {
    const { data } = await apiClient.post<BookResponse>('/books/generate', payload)
    return data
  },

  async list(): Promise<BookSummary[]> {
    const { data } = await apiClient.get<BookSummary[]>('/books/')
    return data
  },

  async getById(bookId: string): Promise<BookResponse> {
    const { data } = await apiClient.get<BookResponse>(`/books/${bookId}`)
    return data
  },
}
