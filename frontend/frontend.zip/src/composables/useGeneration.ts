import { ref } from 'vue'
import { useLocalStorage } from '@vueuse/core'
import { booksApi } from '@/api/books'
import { useDrawingStore } from '@/store/drawing'
import type { BookRequest } from '@/types/book'

// Persist draft so kids don't lose progress if tab closes
const draftKey = 'tailormade:book-draft'

export function useGeneration() {
  const drawing = useDrawingStore()
  const isGenerating = ref(false)
  const error = ref<string | null>(null)
  const progress = ref(0)

  // LocalStorage draft — survives page refresh
  const draft = useLocalStorage<Partial<BookRequest>>(draftKey, {
    title: '',
    theme: '',
    page_count: 6,
    age_range: '6-9',
    art_style: 'standard',
    character_name: '',
  })

  function updateDraft(updates: Partial<BookRequest>) {
    draft.value = { ...draft.value, ...updates }
  }

  function clearDraft() {
    draft.value = {
      title: '',
      theme: '',
      page_count: 6,
      age_range: '6-9',
      art_style: 'standard',
      character_name: '',
    }
  }

  async function generate(payload: BookRequest) {
    isGenerating.value = true
    error.value = null
    progress.value = 0

    // Simulate progress ticks while waiting (actual progress isn't exposed by fal.ai)
    const ticker = setInterval(() => {
      if (progress.value < 85) progress.value += Math.random() * 8
    }, 1500)

    try {
      const book = await booksApi.generate(payload)
      progress.value = 100
      drawing.setBook(book)
      clearDraft() // Clear draft on success
      return book
    } catch (err: unknown) {
      error.value = err instanceof Error ? err.message : 'Generation failed. Please try again.'
      return null
    } finally {
      clearInterval(ticker)
      isGenerating.value = false
    }
  }

  return {
    draft,
    isGenerating,
    error,
    progress,
    updateDraft,
    clearDraft,
    generate,
  }
}
