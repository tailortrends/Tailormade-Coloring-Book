import anthropic
from app.config import get_settings

settings = get_settings()

# Layer 1: instant blocklist — no API call needed
_BLOCKED_KEYWORDS = {
    "violence", "blood", "gore", "weapon", "gun", "knife", "death", "kill",
    "murder", "war", "bomb", "nude", "naked", "sex", "adult", "porn",
    "drugs", "alcohol", "beer", "wine", "cigarette", "smoking",
    "hate", "racist", "slur", "curse", "profanity",
}


def _layer1_check(text: str) -> tuple[bool, str]:
    """Fast keyword scan. Returns (is_safe, reason)."""
    lowered = text.lower()
    for word in _BLOCKED_KEYWORDS:
        if word in lowered:
            return False, f"Content contains inappropriate term: '{word}'"
    return True, ""


async def _layer2_check(text: str) -> tuple[bool, str]:
    """Claude Haiku semantic check for edge cases layer 1 misses."""
    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    response = await client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=100,
        system=(
            "You are a content safety filter for a children's coloring book app (ages 3-12). "
            "Review the prompt and respond with ONLY 'SAFE' or 'UNSAFE: <brief reason>'. "
            "Flag anything violent, sexual, scary, involving real weapons, drugs, or inappropriate "
            "for young children. Allow animals, fantasy, adventure, and family themes."
        ),
        messages=[{"role": "user", "content": f"Check this coloring book prompt: {text}"}],
    )
    result = response.content[0].text.strip()
    if result.startswith("UNSAFE"):
        reason = result.replace("UNSAFE:", "").strip()
        return False, reason
    return True, ""


async def is_content_safe(text: str) -> tuple[bool, str]:
    """
    Full two-layer check.
    Returns (is_safe, reason_if_unsafe).
    Layer 1 is instant; layer 2 only runs if layer 1 passes.
    If layer 2 (Anthropic) is unavailable, falls back to layer 1 only.
    """
    safe, reason = _layer1_check(text)
    if not safe:
        return False, reason

    # Only hit Anthropic API if layer 1 passed
    try:
        safe, reason = await _layer2_check(text)
        return safe, reason
    except Exception as exc:
        # If Anthropic API is unavailable (no credits, network error, etc.),
        # fall back to layer 1 only — still safe for kids since keywords are blocked.
        print(f"⚠️  Anthropic content filter unavailable ({exc}), using keyword filter only.")
        return True, ""
