import firebase_admin
from contextlib import asynccontextmanager
from firebase_admin import credentials
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import books, auth, photos

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ────────────────────────────────────────────────────────────────
    try:
        if not firebase_admin._apps:
            cred = credentials.Certificate(settings.firebase_service_account_path)
            firebase_admin.initialize_app(cred)
        print("✅ TailorMade API ready")
    except FileNotFoundError:
        print(
            "⚠️  firebase-service-account.json not found — "
            "Firebase Auth will NOT work. Download it from Firebase Console → "
            "Project Settings → Service Accounts → Generate new private key."
        )
        print("✅ TailorMade API ready (limited — no Firebase)")
    yield
    # ── Shutdown ───────────────────────────────────────────────────────────────
    print("👋 TailorMade API shutting down")


def create_app() -> FastAPI:
    app = FastAPI(
        title="TailorMade Coloring Book API",
        description="AI-powered personalized coloring book generator",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
    )

    # ── CORS ───────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Routers ────────────────────────────────────────────────────────────────
    app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(books.router, prefix="/api/v1/books", tags=["books"])
    app.include_router(photos.router, prefix="/api/v1/photos", tags=["photos"])

    @app.get("/health")
    async def health():
        return {"status": "ok", "app": "TailorMade Coloring Book", "version": "1.0.0"}

    return app


app = create_app()
