from datetime import datetime, timezone
from fastapi import Depends, HTTPException, status
from firebase_admin import firestore

from app.config import get_settings
from app.middleware.auth import get_current_user

settings = get_settings()


def _today_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


async def check_rate_limit(user: dict = Depends(get_current_user)) -> dict:
    """
    Enforce daily generation limits per user tier.
    Free tier  → settings.free_daily_limit   (default: 1/day)
    Premium    → settings.premium_daily_limit (default: 10/day)
    Tier is stored in Firestore users/{uid}.tier

    NOTE: This only CHECKS the limit. Call increment_usage() after
    successful generation to actually consume a slot.
    """
    uid = user["uid"]
    db = firestore.client()
    today = _today_key()

    user_ref = db.collection("users").document(uid)
    usage_ref = db.collection("usage").document(f"{uid}_{today}")

    user_doc = user_ref.get()
    tier = "free"
    if user_doc.exists:
        tier = user_doc.to_dict().get("tier", "free")

    limit = settings.premium_daily_limit if tier == "premium" else settings.free_daily_limit

    usage_doc = usage_ref.get()
    count = usage_doc.to_dict().get("count", 0) if usage_doc.exists else 0

    if count >= limit:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Daily limit of {limit} book(s) reached. "
            f"{'Upgrade to premium for more.' if tier == 'free' else 'Try again tomorrow.'}",
        )

    user["tier"] = tier
    return user


def increment_usage(uid: str) -> None:
    """Increment the daily usage counter AFTER a successful generation."""
    db = firestore.client()
    today = _today_key()
    usage_ref = db.collection("usage").document(f"{uid}_{today}")

    usage_doc = usage_ref.get()
    count = usage_doc.to_dict().get("count", 0) if usage_doc.exists else 0
    usage_ref.set({"count": count + 1, "uid": uid, "date": today}, merge=True)
