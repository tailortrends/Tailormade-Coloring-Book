import uuid
from fastapi import APIRouter, Depends, HTTPException, status

from app.middleware.auth import get_current_user
from app.middleware.rate_limit import check_rate_limit, increment_usage
from app.models.book import BookRequest, BookResponse, BookSummary, PageResult
from app.services.content_filter import is_content_safe
from app.services.scene_planner import plan_scenes
from app.services.image_gen import generate_pages
from app.services.pdf_builder import build_pdf
from app.services.storage import upload_bytes, build_key
from app.services.firebase_db import save_book, get_user_books, get_book, now_iso

router = APIRouter()


@router.post("/generate", response_model=BookResponse, status_code=status.HTTP_201_CREATED)
async def generate_book(
    request: BookRequest,
    user: dict = Depends(check_rate_limit),  # includes auth + rate limit
):
    """
    Full 8-step pipeline:
    1. Content safety check
    2. Plan scenes (no API cost)
    3. Generate all page images concurrently via fal.ai
    4. Clean line art (binary threshold)
    5. Build print-ready PDF
    6. Upload all assets to Cloudflare R2
    7. Persist metadata to Firestore
    8. Return full BookResponse
    """
    uid = user["uid"]
    book_id = str(uuid.uuid4())

    # ── Step 1: Content safety ─────────────────────────────────────────────────
    full_text = f"{request.title} {request.theme}"
    safe, reason = await is_content_safe(full_text)
    if not safe:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Content not suitable for children's coloring book: {reason}",
        )

    # ── Step 2: Plan scenes ────────────────────────────────────────────────────
    scenes = plan_scenes(
        theme=request.theme,
        page_count=request.page_count,
        art_style=request.art_style,
        age_range=request.age_range,
        character_name=request.character_name,
    )

    # ── Steps 3 & 4: Generate + clean images concurrently ─────────────────────
    processed_scenes = await generate_pages(scenes)

    # ── Step 5: Build PDF ──────────────────────────────────────────────────────
    pdf_bytes = build_pdf(request.title, processed_scenes)

    # ── Step 6: Upload to R2 ───────────────────────────────────────────────────
    page_results = []
    for scene in processed_scenes:
        page_num = scene["page_number"]

        image_url = upload_bytes(
            scene["image_bytes"],
            build_key(uid, book_id, f"page_{page_num:02d}.png"),
            "image/png",
        )
        thumbnail_url = upload_bytes(
            scene["thumbnail_bytes"],
            build_key(uid, book_id, f"page_{page_num:02d}_thumb.jpg"),
            "image/jpeg",
        )
        page_results.append(
            PageResult(
                page_number=page_num,
                scene_description=scene["description"],
                image_url=image_url,
                thumbnail_url=thumbnail_url,
            )
        )

    pdf_url = upload_bytes(
        pdf_bytes,
        build_key(uid, book_id, "book.pdf"),
        "application/pdf",
    )

    # ── Step 7: Persist to Firestore ───────────────────────────────────────────
    book = BookResponse(
        book_id=book_id,
        title=request.title,
        theme=request.theme,
        page_count=request.page_count,
        pages=page_results,
        pdf_url=pdf_url,
        created_at=now_iso(),
        user_uid=uid,
    )
    save_book(book)
    increment_usage(uid)  # Only count after successful generation

    # ── Step 8: Return ─────────────────────────────────────────────────────────
    return book


@router.get("/", response_model=list[BookSummary])
async def list_books(user: dict = Depends(get_current_user)):
    """Return the authenticated user's book gallery (most recent first)."""
    return get_user_books(user["uid"])


@router.get("/{book_id}", response_model=BookResponse)
async def get_book_detail(book_id: str, user: dict = Depends(get_current_user)):
    """Return full book detail. Enforces ownership."""
    data = get_book(book_id, user["uid"])
    if not data:
        raise HTTPException(status_code=404, detail="Book not found.")
    return BookResponse(**data)
